#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Phase 1 迁移脚本：把 calendar.html 抽成 events.json（scaffold + 事件模板）。
只运行一次。生成后 calendar.html 可由 gen_calendar.py 从 events.json 重建。
"""
import re, json, io

SRC = 'calendar.html'
OUT = 'events.json'

h = io.open(SRC, encoding='utf-8').read()

# 1) 收集所有目标锚点（按文档顺序排列）
targets = []  # list of (start, end, match_text, kind)

# (a) cal-ev 网格事件
for m in re.finditer(r'<a class="cal-ev[^"]*"[^>]*>.*?</a>', h, re.S):
    targets.append((m.start(), m.end(), m.group(0), 'cal'))

# (b) 前瞻哨链接：非 cal-ev、且其前 160 字符内有金色游戏名单元格
#     （<b style="color:var(--gold)">游戏名</b>），以此与网格表格区分
for m in re.finditer(r'<a\b[^>]*>.*?</a>', h, re.S):
    if 'cal-ev' in m.group(0):
        continue
    before = h[max(0, m.start() - 160):m.start()]
    if 'color:var(--gold)' in before:
        targets.append((m.start(), m.end(), m.group(0), 'forward'))

targets.sort(key=lambda x: x[0])

# 2) 用占位符重组脚手架，并抽取每个事件的元数据
scaffold = []
cursor = 0
events = []
tag_re = re.compile(r'<[^>]+>')
for i, (s, e, txt, kind) in enumerate(targets):
    scaffold.append(h[cursor:s])          # 非目标文本原样保留
    scaffold.append('<<EVT_%d>>' % i)     # 占位符
    cursor = e

    href = re.search(r'href="([^"]+)"', txt).group(1)
    inner = re.sub(r'</?a\b[^>]*>', '', txt)
    inner_text = tag_re.sub('', inner).strip()
    title_attr = None
    mt = re.search(r'title="([^"]*)"', txt)
    if mt:
        title_attr = mt.group(1)

    if kind == 'cal':
        parts = inner_text.split(' ', 1)
        game = parts[0]
        title = parts[1] if len(parts) > 1 else inner_text
    else:
        # 前瞻哨：游戏名在锚点前的 <b> 单元格里
        before = h[max(0, s - 160):s]
        mb = re.findall(r'<b[^>]*>(.*?)</b>', before, re.S)
        game = tag_re.sub('', mb[-1]).strip() if mb else ''
        title = inner_text
    source_name = (title_attr or game).strip()

    # 模板：href 值替换为 __SRC__，生成时再换回 source_url
    template = txt.replace('href="%s"' % href, 'href="__SRC__"', 1)

    events.append({
        'id': 'E%03d' % i,
        'kind': kind,
        'game': game,
        'title': title,
        'source_url': href,
        'source_name': source_name,
        'anchor': template,
    })

scaffold.append(h[cursor:])   # 末尾原样保留
scaffold = ''.join(scaffold)

# 3) 写出
doc = {
    'meta': {
        'generated_by': 'extract_events.py',
        'source_file': SRC,
        'event_count': len(events),
        'note': 'scaffold 中的 <<EVT_i>> 由 gen_calendar.py 用 events[i].anchor 替换 __SRC__ 回填。',
    },
    'scaffold': scaffold,
    'events': events,
}
io.open(OUT, 'w', encoding='utf-8').write(json.dumps(doc, ensure_ascii=False, indent=1))

# 4) 诊断
print('cal-ev 事件:', sum(1 for e in events if e['kind'] == 'cal'))
print('前瞻哨链接:', sum(1 for e in events if e['kind'] == 'forward'))
print('总事件:', len(events))
print('占位符总数:', scaffold.count('<<EVT_'))
print('脚手架长度:', len(scaffold), ' 原文件长度:', len(h))
print('\n样例(前3条):')
for e in events[:3]:
    print(' ', e['kind'], '|', e['game'], '|', e['title'][:24], '|', e['source_url'][:50])
