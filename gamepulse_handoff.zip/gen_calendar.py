#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Phase 1 生成器：读 events.json -> 重建 calendar.html。
占位符 <<EVT_i>> 用 events[i].anchor 回填，anchor 内 __SRC__ 换回 source_url。
"""
import json, io, os, sys, datetime, re

doc = json.load(io.open('events.json', encoding='utf-8'))
scaffold = doc['scaffold']
events = doc['events']
feed_events = doc.get('feed_events', [])

def render(ev):
    return ev['anchor'].replace('__SRC__', ev.get('source_url', ''))

out = scaffold
# scaffold 是可复用模板，但“今天（MM-DD）”属于生成时态信息，不能随模板固化。
today_mmdd = datetime.date.today().strftime('%m-%d')
out = re.sub(r'今天（\d{2}-\d{2}）', '今天（%s）' % today_mmdd, out)
retired = []
for i, ev in enumerate(events):
    token = '<<EVT_%d>>' % i
    if token not in out:
        # anchor 为空 = 该节点已被主动退役（过期清理 / 专武过滤），scaffold 同步移除了占位符，属正常
        if not (ev.get('anchor') or '').strip():
            retired.append(i)
        else:
            print('WARN: 占位符 %s 未找到，但 anchor 非空 -> events[%d] %s'
                  % (token, i, ev.get('game', '')))
        continue
    out = out.replace(token, render(ev), 1)
if retired:
    print('    已退役节点 %d 个（anchor 空，跳过回填）: %s'
          % (len(retired), ','.join(map(str, retired))))

# Phase 4：信源快报（promote 进来的"可采用"条目）渲染进 <<EVT_FEED>>
feed_html = ''.join(render(ev) for ev in feed_events)
if '<<EVT_FEED>>' in out:
    out = out.replace('<<EVT_FEED>>', feed_html, 1)

# 兜底：任何残留占位符 / __SRC__ 都是错误
assert not re.search(r'<<EVT_\d+>>', out), '存在未替换的数字占位符'
assert '<<EVT_FEED>>' not in out, '存在未替换的 <<EVT_FEED>>'
assert '__SRC__' not in out, '存在未替换 __SRC__'

dst = sys.argv[1] if len(sys.argv) > 1 else 'calendar.html'
_tmp = dst + '.' + str(int(datetime.datetime.now().timestamp()))
io.open(_tmp, 'w', encoding='utf-8').write(out)
try:
    os.replace(_tmp, dst)
except OSError:
    try:
        os.remove(dst)
        os.rename(_tmp, dst)
    except OSError:
        print('WARN: cannot overwrite', dst, '(locked), content in', _tmp)
        import sys as _s; _s.exit(0)
print('written ->', dst, '(', len(out), 'bytes )')
