# -*- coding: utf-8 -*-
"""daily_refresh.py — GamePulse 每日刷新 + 自洽校验 + 日志（按"自洽提示词体系"）
流程：① meme_radar 采集 ② 按真实失败源更新源覆盖报告 ③ cross_words 重生词云(H)
      ④ rebuild_main 重建主站 ⑤ 自洽校验 ⑥ 写日志
"""
import re, io, os, sys, json, datetime, subprocess, ast, urllib.parse

BASE = os.path.dirname(os.path.abspath(__file__))
PY = "C:/Users/shudizhao/.workbuddy/binaries/python/versions/3.13.12/python.exe"
TODAY = datetime.date.today().strftime("%Y-%m-%d")
MEMO = []  # 运行日志
problems = []  # (层级, 板块/位置, 问题, 违反维度, 严重度, 修复建议) —— 必须在 ④ 之前定义（④ 的 gen_calendar 失败会 append）
# Windows 下子进程 stdout 走管道默认 GBK，脚本里打印 →/★/emoji 会 UnicodeEncodeError 假死非零退出，强制 UTF-8
ENV = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")

def log(s):
    MEMO.append(s)
    print(s)

# ---------- ① 采集 ----------
log("【① 采集】运行 meme_radar.py ...")
r = subprocess.run([PY, "meme_radar.py"], cwd=BASE, capture_output=True, text=True, encoding="utf-8", env=ENV)
status = {}
m = re.search(r"状态:\s*(\{.*\})", r.stdout + r.stderr)
if m:
    try:
        status = ast.literal_eval(m.group(1))
    except Exception:
        pass
ok = [k for k, v in status.items() if str(v).startswith("OK")]
fail = {k: v for k, v in status.items() if not str(v).startswith("OK")}
log(f"    状态: {status}")
log(f"    通过 {len(ok)}/6 · 失败/跳过 {len(fail)}: {fail if fail else '无'}")
today_meme = os.path.join(BASE, "collectors", "meme_" + TODAY.replace("-", "") + ".json")
meme_ready = r.returncode == 0 and os.path.exists(today_meme)

# ⑦ 全网热榜交叉采集（五平台 → game/ACG 过滤）
log("【①b 热榜】运行 collector_public.py（五平台热榜 → 游戏/ACG 交叉采集）...")
rp = subprocess.run([PY, "collector_public.py"], cwd=BASE, capture_output=True, text=True, encoding="utf-8", env=ENV)
pub_status = {}
pm = re.search(r"状态:\s*(\{.*\})", rp.stdout + rp.stderr)
if pm:
    try:
        pub_status = ast.literal_eval(pm.group(1))
    except Exception:
        pass
pub_ok = [k for k, v in pub_status.items() if str(v).startswith("OK")]
pub_fail = {k: v for k, v in pub_status.items() if not str(v).startswith("OK")}
pub_total = sum(1 for k, v in pub_status.items() if v)
log(f"    状态: {pub_status}")
log(f"    通过 {len(pub_ok)}/5 平台 · 失败 {len(pub_fail)}: {pub_fail if pub_fail else '无'}")
today_public = os.path.join(BASE, "collectors", "public_hotlist_" + TODAY.replace("-", "") + ".json")
public_ready = rp.returncode == 0 and os.path.exists(today_public)
# 热榜采集非阻断（单平台失败不阻断整体刷新），仅写进日志供溯源
if rp.returncode != 0:
    log(f"    ⚠ collector_public 非零退出（非阻断）：{(rp.stderr or rp.stdout).strip()[:200]}")
    # 不加入 problems（热榜是增量信号，缺失不影响日报核心板块）
if r.returncode != 0:
    problems.append(("刷新", "meme_radar.py", f"非零退出：{(r.stderr or r.stdout).strip()[:200]}",
                     "当日采集完整性", "阻断", "修复采集错误后重新运行；不得沿用历史采集结果"))
if not os.path.exists(today_meme):
    problems.append(("刷新", "当日采集文件", f"缺少 {os.path.basename(today_meme)}", "当日采集完整性", "阻断",
                     "先成功生成当天 meme 文件；refresh_content 已禁止回退到历史文件"))

# ①c 糖果梦 AI 游戏日报（非阻断 → 行业情报增量信号）
log("【①c tgmeng】运行 collector_tgmeng.py（糖果梦 AI 游戏日报 → 行���综述）...")
rt = subprocess.run([PY, "collector_tgmeng.py"], cwd=BASE, capture_output=True, text=True, encoding="utf-8", env=ENV)
if rt.returncode == 0:
    lines = [l for l in (rt.stdout + rt.stderr).split("\n") if l.strip()]
    for l in lines:
        if "✓" in l or "⚠" in l:
            log(f"    {l.strip()}")
else:
    log(f"    ⚠ collector_tgmeng 非零退出（非阻断）：{(rt.stderr or rt.stdout).strip()[:200]}")
# tgmeng 是 AI 综述信号，非阻断——缺失不影响日报核心板块

# ---------- ② 按真实失败源更新源覆盖报告 ----------
fn = os.path.join(BASE, "daily.html")
h = io.open(fn, encoding="utf-8").read()
# 合并 B站 + 全网热榜 的失败源
all_fail = dict(fail)
all_fail.update({f"热榜:{k}": v for k, v in pub_fail.items()})
if all_fail:
    failtxt = "、".join(f"{k}({v})" for k, v in all_fail.items())
    new_fail = f"本次失败源：{failtxt}（单源失败自动跳过，不阻断整体生成）· 通过 B站 {len(ok)}/6 + 热榜 {len(pub_ok)}/5"
else:
    new_fail = f"本次失败源：无（通过 B站 {len(ok)}/6 + 热榜 {len(pub_ok)}/5，单源失败自动跳过）"
h = re.sub(r"本次失败源：[^<]*", new_fail, h)
# 写临时文件再替换，防止预览窗格锁住目标文件导致 PermissionError
_tmp = fn + "." + datetime.datetime.now().strftime("%H%M%S")
io.open(_tmp, "w", encoding="utf-8").write(h)
try:
    os.remove(fn)
except OSError:
    pass
os.rename(_tmp, fn)
log("【② 源覆盖报告】已按真实失败源更新：" + new_fail)

# ---------- ②b 热榜→词云交叉加权 ----------
if public_ready:
    log("【②b 加权】运行 boost_hotlist.py（热榜→词云交叉加权）...")
    rb = subprocess.run([PY, "boost_hotlist.py"], cwd=BASE, capture_output=True, text=True, encoding="utf-8", env=ENV)
    log("    " + (rb.stdout.strip().splitlines()[-1] if rb.stdout.strip() else "(无加权)"))
    # 加权非阻断：热榜数据缺失时词云仍用原始 heat，不影响渲染
    if rb.returncode != 0:
        log("    ⚠ boost_hotlist 非零退出（非阻断）：" + rb.stderr.strip()[:160])
else:
    log("【②b 加权】跳过 boost_hotlist：当日热榜未就绪")

# ---------- ③ 重生词云(H) ----------
log("【③ 词云】运行 cross_words.py（统一 H 口径）...")
r2 = subprocess.run([PY, "cross_words.py"], cwd=BASE, capture_output=True, text=True, encoding="utf-8", env=ENV)
log("    " + (r2.stdout.strip().splitlines()[-1] if r2.stdout.strip() else r2.stderr.strip()[:200]))
if r2.returncode != 0:
    problems.append(("刷新", "cross_words.py", f"非零退出：{(r2.stderr or r2.stdout).strip()[:200]}",
                     "当日词云完整性", "阻断", "先基于当天采集重产 wordcloud_terms.json（date 必须等于当天），再重跑"))

# ---------- ③-信源采集（Phase 2，非阻塞） ----------
# 每次 refresh 同步各信源存活状态与最新条目到 inbox/（信源扩充=往 sources.toml 加一条）。
# 设 COLLECT_SOURCES=0 可跳过（避免刷新时联网耗时）。
if os.environ.get('COLLECT_SOURCES', '1') != '0':
    try:
        log("【③信源】运行 collect_sources.py（sources.toml -> inbox）...")
        rsrc = subprocess.run([PY, 'collect_sources.py'], cwd=BASE,
                               capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=240)
        for line in rsrc.stdout.strip().splitlines()[-3:]:
            log("    " + line)
        if rsrc.returncode != 0:
            log("    ⚠ collect_sources 非零退出（非阻断）：" + rsrc.stderr.strip()[:160])
    except Exception as e:
        log("    ⚠ collect_sources 跳过（非阻断）：" + repr(e)[:160])
else:
    log("【③信源】COLLECT_SOURCES=0，跳过信源采集")

# ③-2 准入安检（Phase 3，非阻塞）：inbox 候选 -> sources_curated.json + 准入报告.md
try:
    log("【③准入】运行 admit_sources.py（inbox -> 准入安检）...")
    radm = subprocess.run([PY, 'admit_sources.py'], cwd=BASE,
                          capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=180)
    for line in radm.stdout.strip().splitlines()[-2:]:
        log("    " + line)
    if radm.returncode != 0:
        log("    ⚠ admit_sources 非零退出（非阻断）：" + radm.stderr.strip()[:160])
except Exception as e:
    log("    ⚠ admit_sources 跳过（非阻断）：" + repr(e)[:160])

# ③-3 策展晋升（Phase 4，非阻塞）：curated 的 adopt 条目 -> events.json 信源快报
try:
    log("【③策展】运行 promote_sources.py（adopt -> 信源快报）...")
    rpro = subprocess.run([PY, 'promote_sources.py'], cwd=BASE,
                          capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=120)
    for line in rpro.stdout.strip().splitlines()[-2:]:
        log("    " + line)
    if rpro.returncode != 0:
        log("    ⚠ promote_sources 非零退出（非阻断）：" + rpro.stderr.strip()[:160])
except Exception as e:
    log("    ⚠ promote_sources 跳过（非阻断）：" + repr(e)[:160])

# ③-4 信源自发现（Phase 5，非阻塞）：扫已登记源的同域栏目/跨域站点 + 行业种子 -> 新信源建议
# 脚本内置 7 天节流，日跑不会每天联网重扫；DISCOVER_SOURCES=0 可完全关闭。
if os.environ.get('DISCOVER_SOURCES', '1') != '0':
    try:
        log("【③自发现】运行 discover_sources.py（扫描 -> 新信源建议）...")
        rdis = subprocess.run([PY, 'discover_sources.py'], cwd=BASE,
                              capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=600)
        for line in rdis.stdout.strip().splitlines()[-3:]:
            log("    " + line)
        if rdis.returncode != 0:
            log("    ⚠ discover_sources 非零退出（非阻断）：" + rdis.stderr.strip()[:160])
    except Exception as e:
        log("    ⚠ discover_sources 跳过（非阻断）：" + repr(e)[:160])
else:
    log("【③自发现】DISCOVER_SOURCES=0，跳过信源自发现")

# ③-4.5 内容板块自动刷新（梗雷达/TOP10）：用 ① 采集到的当天 meme 结果重刷 #hot/#radar 两块
# 必须排在 meme_radar 采集之后（读 collectors/meme_YYYYMMDD.json）、且在 ③-5 unify_heat 之前
# （本步只写原始播放量，H 由 ③-5 统一换算，保持单一职责、避免两处各写一套 H 对不上）。
if meme_ready:
    try:
        log("【③内容】运行 refresh_content.py（当天采集 -> 重刷梗雷达/TOP10）...")
        rcon = subprocess.run([PY, 'refresh_content.py'], cwd=BASE,
                              capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=60)
        for line in rcon.stdout.strip().splitlines()[-3:]:
            log("    " + line)
        if rcon.returncode != 0:
            problems.append(("刷新", "refresh_content.py", f"非零退出：{(rcon.stderr or rcon.stdout).strip()[:200]}",
                             "当日内容完整性", "阻断", "修复后重跑；不得沿用历史采集内容"))
    except Exception as e:
        problems.append(("刷新", "refresh_content.py", repr(e)[:200], "当日内容完整性", "阻断",
                         "修复执行异常后重新运行"))
else:
    log("【③内容】跳过 refresh_content：当天采集未就绪，拒绝用历史内容冒充今日刷新")

# ③-5 热度口径统一（跨板块 H）：把 TOP10/梗雷达/视觉焦点 的原始播放量换算成 H
# 必须排在 meme_radar 采集之后（采集会写回原始播放量）、rebuild_main 之前（主站从 daily.html 取材）。
try:
    log("【③热度】运行 unify_heat.py（原始播放量 -> 统一 H）...")
    rheat = subprocess.run([PY, 'unify_heat.py'], cwd=BASE,
                           capture_output=True, text=True, encoding='utf-8', env=ENV, timeout=60)
    log("    " + (rheat.stdout.strip().splitlines()[0] if rheat.stdout.strip() else rheat.stderr.strip()[:160]))
    if rheat.returncode != 0:
        log("    ⚠ unify_heat 非零退出（非阻断）：" + rheat.stderr.strip()[:160])
except Exception as e:
    log("    ⚠ unify_heat 跳过（非阻断）：" + repr(e)[:160])

# ③-5.5 糖果梦 AI 日报 -> 站内热度融合（非阻断）：概念匹配 + boost 权重
try:
    log("【③AI融合】运行 boost_tgmeng.py（日报概念 -> 站内交叉匹配）...")
    rb = subprocess.run([PY, "boost_tgmeng.py"], cwd=BASE,
                        capture_output=True, text=True, encoding="utf-8", env=ENV, timeout=120)
    for line in rb.stdout.strip().splitlines()[-4:]:
        log("    " + line)
    if rb.returncode != 0:
        log("    boost_tgmeng 非零退出（非阻断）：" + (rb.stderr or "").strip()[:160])
except Exception as e:
    log("    boost_tgmeng 跳过（非阻断��：" + repr(e)[:160])

# ③-6 糖果梦 AI 日报卡片 + badge 注入（非阻断）：无外链，纯站内概念信号
try:
    import glob as _g, re as _re
    tg_files = sorted(_g.glob(os.path.join(BASE, "collectors", "tgmeng_daily_*.json")), reverse=True)
    bt_files = sorted(_g.glob(os.path.join(BASE, "collectors", "tgmeng_boost_*.json")), reverse=True)
    _daily_path = os.path.join(BASE, "daily.html")
    if not os.path.exists(_daily_path):
        log("    daily.html 不存在，跳过 tgmeng 卡片+badge 注入")
    elif not tg_files:
        log("    未找到 tgmeng_daily_*.json，跳过")
    else:
        _tdata = json.load(open(tg_files[0], encoding="utf-8"))
        _entry = _tdata.get("entry")
        if _entry and isinstance(_entry, dict) and _entry.get("title") and not _entry.get("error"):
            _entry_count = _tdata.get("all_entries_count", 0)
            _concepts = _entry.get("tags") or []
            _boost_data = {}
            if bt_files:
                try:
                    _boost_data = json.load(open(bt_files[0], encoding="utf-8"))
                except Exception:
                    pass
            _summ = _boost_data.get("summary", {})
            _matched_c = _summ.get("matched_concepts", [])
            _unmatched_c = _summ.get("unmatched_concepts", [])
            _concept_rows = ""
            for _tag in _concepts:
                if _tag in _matched_c:
                    _concept_rows += '<span class="tgmeng-concept-matched">✅ ' + _tag + '</span>'
                else:
                    _concept_rows += '<span class="tgmeng-concept-trend">🔀 ' + _tag + '</span>'
            _ai_parts = []
            if _entry.get("ai_platform"): _ai_parts.append(str(_entry["ai_platform"]))
            if _entry.get("ai_model"): _ai_parts.append(str(_entry["ai_model"]))
            if _entry.get("generated_at"): _ai_parts.append("生成: " + str(_entry["generated_at"])[:16])
            _ai_meta = " · ".join(_ai_parts)
            _card_html = ('<section id="tgmeng">'
                '<div class="sec-title">'
                '<span class="bar" style="background:linear-gradient(135deg,#c792ea,#4da3ff)"></span>'
                'AI 趋势信号 <small>糖果梦 · 日报概念融合 · ' + str(_entry_count) + ' 期历史</small>'
                '</div>'
                '<div class="tgmeng-card">'
                '<div class="tgmeng-head">'
                '<h3>' + str(_entry.get("title", "")) + '</h3>'
                '<span class="tgmeng-date">' + str(_entry.get("date", "")) + '</span>'
                '</div>'
                '<div class="tgmeng-concept-bar">' + _concept_rows + '</div>'
                '<div class="tgmeng-meta">'
                '<span>' + _ai_meta + '</span>'
                '<span class="tgmeng-signal-note">'
                '信号匹配: ' + str(len(_matched_c)) + '/' + str(len(_concepts)) + ' 概念已确认')
            if _unmatched_c:
                _card_html += ' · ' + str(len(_unmatched_c)) + ' 待观察'
            _card_html += '</span></div></div></section>'

            _daily_content = io.open(_daily_path, encoding="utf-8").read()
            _badge_count = 0
            if _boost_data and _boost_data.get("matched_items"):
                for _item in _boost_data["matched_items"]:
                    _url = _item.get("url", "")
                    _concept = _item.get("concept", "")
                    if not _url or "bilibili.com/video/" not in _url:
                        continue
                    _badge_attr = 'data-tgmeng="' + _concept + '"'
                    if _badge_attr not in _daily_content:
                        _old = 'href="' + _url + '"'
                        _new = _old + ' ' + _badge_attr
                        if _old in _daily_content and _new not in _daily_content:
                            _daily_content = _daily_content.replace(_old, _new, 1)
                            _badge_count += 1
                if _badge_count:
                    log("    " + str(_badge_count) + " 条站内内容已标记 AI 确认信号")

            if 'id="tgmeng"' not in _daily_content:
                _daily_content = _daily_content.replace(
                    '\n<section id="source"',
                    '\n' + _card_html + '\n<section id="source"')
            else:
                _daily_content = _re.sub(
                    r'<section id="tgmeng">.*?</section>',
                    _card_html, _daily_content, flags=_re.S)
                log("    daily.html 已含旧 tgmeng 卡片，已替换为新版（概念信号）")
            try:
                with open(_daily_path, "w", encoding="utf-8") as _fh:
                    _fh.write(_daily_content)
                log("    AI 趋势信号卡片已注入 daily.html（" + str(len(_concepts)) + " 概念）")
            except PermissionError:
                log("    daily.html 被锁定（IDE 预览窗口），跳过写入")
        else:
            log("    tgmeng 数据不可用，跳过卡片+badge 注入")
except Exception as _e:
    log("    tgmeng 卡片+badge 注入跳过（非阻断）：" + repr(_e)[:160])
log(f"整体自洽度：{verdict} ｜ 阻断 {len(blocking)} ｜ 优化 {len(optimizing)}")
