# -*- coding: utf-8 -*-
"""一次性：把 daily.html 里三个非流水线编辑区块（#brief / #board / #media）
换成 2026-08-05 已核验条目。所有条目均取自 events.json 的 feed_events，
每条都有真实 source_url + 已校准的真实发布日期。"""
import io
import os
import re
import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
FN = os.path.join(BASE, "daily.html")
TODAY = "2026-08-05"

BRIEF = (
    '<section id="brief"><div class="sec-title"><span class="bar"></span>今日速览 '
    '<small>一张图看懂今天 · 每条都可点回原文</small></div><div class="brief-grid">'
    '<div class="brief-card"><span class="brief-label" style="background:#ff5c39">'
    '&#127917; 主线</span><b>《幻兽帕鲁》IP 手游官宣</b>'
    '<small>Pocketpair × 新加坡 Garena 合作开发《Palworld Online》，'
    '自我定位 MMORPG＋生存建造、提供官方服务器；国服代理未公布（白鲸出海 08-04）</small></div>'
    '<div class="brief-card"><span class="brief-label">&#128206; 信号</span>'
    '<b>腾讯《追逐卡蕾多》</b><small>飞驰蛤蜊工作室，百人团队研发三年，'
    '纯男性向二次元恋爱养成；CJ 期间项目组媒体交流（游戏陀螺 08-05）</small></div>'
    '<div class="brief-card"><span class="brief-label">&#128206; 信号</span>'
    '<b>《火焰纹章：万缕千丝》</b><small>官网上线，公布"穿越时间的救世主"真主角情报'
    '（游民星空 08-04）</small></div>'
    '<div class="brief-card"><span class="brief-label">&#128206; 信号</span>'
    '<b>《QUIET》开启 Steam 测试</b><small>LINE Games 的 1~4 人合作搞笑恐怖新作，'
    '本次首度开放第一关，目标年内全球上市（机核 08-04）</small></div>'
    '<div class="brief-card"><span class="brief-label" style="background:#ffb020">'
    '&#128240; 数据</span><small>游戏陀螺：鹰角夏日嘉年华一口气包下 4 个展馆，'
    '《明日方舟》冲进畅销榜总榜第三（08-03，媒体口径）；GameLook：8 月预计 13 款新游上线，'
    '快手《诡秘之主》独挑大梁（08-03）</small></div></div>'
    '<div class="nav-btns"><a href="#visual" class="nav-btn">&#128247; 视觉焦点</a>'
    '<a href="#board" class="nav-btn">&#128202; 榜单瞭望塔</a>'
    '<a href="#radar" class="nav-btn">&#128293; 内容TOP10</a>'
    '<a href="#hot" class="nav-btn">&#128172; 梗雷达</a>'
    '<a href="#media" class="nav-btn">&#128240; 行业情报</a>'
    '<a href="#source" class="nav-btn">&#128225; 来源</a></div></section>'
)

BOARD = (
    '<section id="board"><div class="sec-title"><span class="bar" style="background:var(--gold)">'
    '</span>榜单瞭望塔 <small>纯数据 / 事件信号 · 数字与排名均标注媒体口径，不自行推算</small></div>'
    '<div class="panel"><h3>&#11088; 事件 &amp; 排位信号</h3><div class="hl-grid">'

    '<a class="hl-item" target="_blank" href="https://www.youxituoluo.com/534738.html">'
    '<b style="color:#ff5c39">鹰角夏日嘉年华包下 4 个展馆</b>'
    '<small>游戏陀螺 08-03 口径：《明日方舟》冲进畅销榜总榜第三 · 线下嘉年华成为 CJ 期间'
    '最大单体展区之一</small></a>'

    '<a class="hl-item" target="_blank" href="http://www.gamelook.com.cn/2026/07/598819/">'
    '<b style="color:#4da3ff">字节《雾影猎人》登顶 Steam 畅销榜</b>'
    '<small>GameLook 07-31 口径 · 搜打撤品类进入冷兵器时代，字节在 PC 端的新试水</small></a>'

    '<a class="hl-item" target="_blank" href="http://www.gamelook.com.cn/2026/08/598971/">'
    '<b style="color:#3fd68f">8 月预计 13 款新游上线</b>'
    '<small>GameLook 08-03 盘点 · 快手《诡秘之主》独挑大梁，被称"MMO 最后一舞"</small></a>'

    '<a class="hl-item" target="_blank" href="https://www.baijing.cn/article/56215">'
    '<b style="color:#ffb020">腾讯清仓式减持 Marvelous</b>'
    '<small>白鲸出海 08-03 · #56215 · 《牧场物语》/《符文工房》厂商，持股降至 &lt;1%，'
    '游戏 IP 授权仍有效</small></a>'

    '<a class="hl-item" target="_blank" href="https://www.baijing.cn/article/56230">'
    '<b style="color:#c792ea">《Palworld Online》官宣</b>'
    '<small>白鲸出海 08-04 · #56230 · Pocketpair × Garena，MMORPG＋生存建造，'
    '官方服务器解决原作联机自费租服问题</small></a>'

    '</div></div><h3 class="sub-t">&#128279; 榜单入口</h3><div class="mod-cards">'
    '<a class="mod-card" target="_blank" href="https://www.bilibili.com/v/popular/all">'
    '<h3>&#128250; B站热门视频</h3><p>全站热门 · 梗与内容动量</p></a>'
    '<a class="mod-card" target="_blank" href="https://www.bilibili.com/v/popular/rank/hot">'
    '<h3>&#128293; B站热门排行</h3><p>排行榜页 · 已接自动抓取</p></a>'
    '<a class="mod-card" target="_blank" href="https://www.reddit.com/r/Games/">'
    '<h3>&#128172; Reddit r/Games</h3><p>海外玩家风向 · 公开 RSS</p></a></div></section>'
)


def fitem(href, title, meta):
    return ('<a class="fitem" target="_blank" href="%s"><div class="ft">%s</div>'
            '<div class="fm"><span>%s</span></div></a>' % (href, title, meta))


MEDIA = (
    '<section id="media"><div class="sec-title"><span class="bar" style="background:var(--blue)">'
    '</span>行业情报站 <small>已注册信源 · 只看近 5 天 · 按内容分类 · 标题即原文标题</small>'
    '<span class="chip" style="margin-left:auto">07-31 ~ 08-05</span></div><div class="feature-grid">'

    '<div class="fcol"><div class="fcol-head"><span class="dot gold"></span>'
    '<h3>政策 · 资本 · 大厂</h3></div>'
    + fitem("https://www.baijing.cn/article/56215",
            "确认了，腾讯清仓式减持《牧场物语》厂商股权，IP 授权仍有效",
            "白鲸出海 · 08-03 · #56215")
    + fitem("https://www.youxituoluo.com/534751.html",
            "百人团队、研发三年：腾讯“麻辣”二游，要勇闯男性恋爱市场",
            "游戏陀螺 · 08-05")
    + fitem("http://www.gamelook.com.cn/2026/08/598971/",
            "8 月预计 13 款新游戏上线！快手《诡秘之主》独挑大梁，“MMO 最后一舞”？",
            "GameLook · 08-03")
    + '</div>'

    '<div class="fcol"><div class="fcol-head"><span class="dot"></span><h3>产品 · 研发</h3></div>'
    + fitem("https://www.gamersky.com/news/202608/2183174.shtml",
            "《火焰纹章：万缕千丝》真主角！官网上线 穿越时间的救世主",
            "游民星空 · 08-04")
    + fitem("https://www.gcores.com/articles/217919",
            "多人合作搞笑恐怖新作《QUIET》现已开启游戏测试",
            "机核 GCORES · 08-04")
    + fitem("https://www.gamersky.com/news/202608/2181745.shtml",
            "《仁王3》DLC 新情报！独眼剑豪登场 江户再陷地狱",
            "游民星空 · 08-03")
    + fitem("https://news.17173.com/content/08042026/084147744.shtml",
            "《轮回之兽》：助你有效管理瘴气的游戏前期指南",
            "17173 网游资讯 · 08-04")
    + '</div>'

    '<div class="fcol"><div class="fcol-head"><span class="dot" style="background:var(--green)">'
    '</span><h3>出海 · 买量 · AI</h3><span class="src">白鲸出海 / GameLook</span></div>'
    + fitem("https://www.baijing.cn/article/56230",
            "《幻兽帕鲁》出手游了？和新加坡厂商 Garena 合作开发",
            "白鲸出海 · 08-04 · #56230")
    + fitem("http://www.gamelook.com.cn/2026/07/598819/",
            "字节新游《雾影猎人》登顶 Steam 畅销榜，搜打撤进入冷兵器时代？",
            "GameLook · 07-31")
    + '</div>'

    '<div class="fcol"><div class="fcol-head"><span class="dot" style="background:var(--purple)">'
    '</span><h3>玩家 · 平台 · 官方公告</h3></div>'
    + fitem("https://news.17173.com/content/08032026/100931101.shtml",
            "首度回应网暴！《明末》制作人夏思源确认续作主角仍是无常",
            "17173 · 08-03")
    + fitem("https://yys.163.com/news/update/20260804/23024_1310103.html",
            "《阴阳师》手游 8 月 5 日维护更新公告（7:30–9:00）",
            "网易官方公告 · 08-04")
    + fitem("https://www.yjwujian.cn/news/match/20260805/36478_1310047.html",
            "永劫无间职业联赛 NPL 秋季赛赛事规则公布",
            "永劫无间官方 · 08-05")
    + fitem("https://www.gamersky.com/news/202608/2181641.shtml",
            "《异度之刃2》NS2 版震惊老玩家 提升惊人",
            "游民星空 · 08-02")
    + '</div></div>'

    '<p class="note" style="margin-top:14px">本区块只收录 sources.toml 已注册信源的条目，'
    '标题与原文一致、日期为真实发布日（RSS 字段 / URL 路径回溯，非采集日）；'
    '近 5 天（07-31 起）之外的自动淘汰。微信好文可直接丢 mp.weixin.qq.com/s/ 链接，'
    '单篇可解析置顶。</p></section>'
)


def main():
    h = io.open(FN, encoding="utf-8").read()
    for sid, new in (("brief", BRIEF), ("board", BOARD), ("media", MEDIA)):
        pat = re.compile(r'<section id="%s".*?</section>' % sid, re.S)
        if not pat.search(h):
            print("⚠ 找不到 #%s" % sid)
            continue
        h = pat.sub(lambda m, n=new: n, h, count=1)
        print("✓ #%s 已重写" % sid)
    tmp = FN + "." + datetime.datetime.now().strftime("%H%M%S%f")
    io.open(tmp, "w", encoding="utf-8").write(h)
    try:
        os.replace(tmp, FN)
    except OSError:
        os.remove(FN)
        os.rename(tmp, FN)


if __name__ == "__main__":
    main()
