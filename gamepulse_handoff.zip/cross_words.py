# -*- coding: utf-8 -*-
"""cross_words.py — 词云「渲染器」（B 方案：词条由 Agent 阅读理解当日标题后写入 wordcloud_terms.json）

设计原则（用户拍板 B）：
- 彻底废除「子串枚举 + 黑名单 / 词库 / 规则打地鼠」那套提取逻辑。
- 本脚本不做任何"理解"：只把 wordcloud_terms.json（Agent 读标题后产出的干净词条）渲染进 wordcloud.html。
- 词条的"是否游戏相关 / 该提炼成什么词 / 归哪一类"全部由 Agent 在读标题时判断，脚本零规则。
"""
import re, io, os, sys, json, datetime, urllib.parse
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
WC_PATH = os.environ.get("WC_OUT_PATH", os.path.join(BASE, "wordcloud.html"))
TERMS_PATH = os.environ.get("WC_TERMS_PATH", os.path.join(BASE, "wordcloud_terms.json"))
today = datetime.date.today()
today_s = today.strftime("%Y-%m-%d")

# 五档配色（与图例、TOP8 提示同源）
CAT_COLOR = {
    "事件/风险": "#ff6b4a",
    "游戏/新品": "#b388ff",
    "行业/数据": "#4dabf7",
    "梗/社区":   "#3fd68f",
    "厂商/平台": "#a0aec0",
}
CAT_HINT = {
    "事件/风险": "负面信号，社区情绪集中，需盯舆情走向",
    "游戏/新品": "产品侧动作，关注版本节奏与玩家反馈",
    "行业/数据": "行业量化信号，可作趋势判断依据",
    "梗/社区":   "玩家自发讨论，内容侧选题富矿",
    "厂商/平台": "平台/厂商动向，多为渠道侧信息",
}

# 游戏/ACG 关键词匹配（hotwords 过滤用）
GAME_KW = re.compile(r'《[^》]+》|游戏|Steam|手游|端游|主机|Switch|PS5|Xbox|电竞|'
                      r'联动|皮肤|版本|赛季|公测|首发|发售|上线|定档|开服|新游|'
                      r'动画|漫画|番|声优|cos|二游|萌|抽卡|氪|局|赛'
                      r'|原神|崩坏|星穹|铁轨|阴阳师|崩铁|绝区|鸣潮|方舟'
                      r'|LOL|王者|和平|穿越|三角洲|坦克|战舰|MH|DNF'
                      r'|DOTA|CS2|CF|PUBG|APEX|VALORANT|OVERWATCH'
                      r'|完蛋|EDG|BLG|TES|JDG|WBG|T1|WE|LGD|RW|TTG|IVL'
                      r'|EVA|火影|海贼|柯洁')

# ===================== 读取 Agent 产出的词条 =====================
if not os.path.exists(TERMS_PATH):
    sys.stderr.write(
        "ERROR: 未找到 wordcloud_terms.json。\n"
        "B 方案下，词云词条须由 Agent 阅读当日标题后生成该文件\n"
        "（读取 collectors/meme_当天.json 与 events.json 的 feed_events，理解语义后提炼）。\n"
        "没有它，脚本无法也无能力自行造词——这正是放弃规则提取的目的。\n")
    sys.exit(1)

doc = json.load(io.open(TERMS_PATH, encoding="utf-8"))
cloud_date = doc.get("date")
# 词云词条由每日值守 Agent 阅读当天真实标题后产出；不允许把旧词条冒充今天。
# 缺 date / 日期不等于今天都直接失败，daily_refresh 会将其记为阻断并停止发布。
if cloud_date != today_s:
    sys.stderr.write(
        f"ERROR: wordcloud_terms.json 日期为 {cloud_date or '缺失'}，不是当天 {today_s}。\n"
        "请先基于 collectors/meme_当天.json 与已准入的当天信源重产词条，再运行 cross_words.py。\n")
    sys.exit(2)
terms = doc.get("terms", [])

# ===================== B站热搜 hotwords 注入（2026-08-04） =====================
# hotwords 是搜索趋势信号，不同于 popular 视频。以前整个采集-展示链路只走视频，
# 热搜词采集进来了但没有面板对接——像《完蛋！我被男同学包围了》这类搜索破圈
# 但还没产出 hit 视频的新品，全站零曝光。
# 这里把当日 game/ACG 热搜词作为 bonus terms 并入词云，source 标"B站热搜"。
HW_PATH = os.path.join(BASE, "collectors", "meme_" + today_s.replace("-", "") + ".json")


def _lcs_len(a, b):
    """最长公共子串长度——用于把热搜词落到当日真实视频页。"""
    if not a or not b:
        return 0
    prev = [0] * (len(b) + 1)
    best = 0
    for i in range(1, len(a) + 1):
        cur = [0] * (len(b) + 1)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                cur[j] = prev[j - 1] + 1
                if cur[j] > best:
                    best = cur[j]
        prev = cur
    return best


_hw_bonus = []
if os.path.exists(HW_PATH):
    _meme = json.load(io.open(HW_PATH, encoding="utf-8"))
    # 当日已采集视频池：热搜词必须能落到一个真实视频页才允许进词云。
    # 2026-08-05 治理：原实现给热搜词拼 search.bilibili.com 搜索链接，违反"禁止搜索页"红线，
    # 改为只保留能匹配到当日真实视频的热搜词，匹配不上的直接丢弃（宁缺毋滥）。
    _pool = []
    for _sec in ("popular", "weekly", "meme_ups", "series"):
        for _v in (_meme.get(_sec) or []):
            _t = (_v.get("title") or "").strip()
            _u = (_v.get("url") or _v.get("href") or "").strip()
            if _t and _u:
                _pool.append((_t, _u))
    _hw_list = sorted(_meme.get("hotwords", []), key=lambda x: -x.get("heat", 0))
    _game_hw = [h for h in _hw_list if GAME_KW.search(h.get("kw", ""))]
    _hw_dropped = []
    for h in _game_hw:
        kw = h.get("kw", "")
        _best_u, _best_n = "", 0
        for _t, _u in _pool:
            n = _lcs_len(kw, _t)
            if n > _best_n:
                _best_u, _best_n = _u, n
        if _best_n < 4:                       # 落不到真实视频页 → 丢弃，绝不拼搜索链接
            _hw_dropped.append(kw)
            continue
        _hw_bonus.append({
            "term": kw, "heat": max(15, int(h.get("heat", 10000) / 50000)),
            "cat": "梗/社区", "sources": ["B站热搜"],
            "href": _best_u,
        })
        if len(_hw_bonus) >= 5:
            break
    if _hw_dropped:
        print(f"B站热搜词丢弃(无真实视频页可落): {len(_hw_dropped)} 条 ({'、'.join(_hw_dropped)})")
if _hw_bonus:
    print(f"B站热搜词云注入: {len(_hw_bonus)} 条 ({'、'.join(h['term'] for h in _hw_bonus)})")
terms = terms + _hw_bonus

# ===================== 构建 rows =====================
# 仅做"安全护栏"（不接搜索链接 / 不跳商店购买页），不做任何内容理解或过滤。
_STORE_PRODUCT = re.compile(r"store\.steampowered\.com/(?:app|sub)/\d+(?!/news)")
# 搜索结果页黑名单：任何站点的搜索页都不是"承载该词的具体页面"，一律拒绝。
_SEARCH_PAGE = re.compile(
    r"search\.bilibili\.com|s\.weibo\.com|/search[/?]|[?&](?:keyword|q|wd|query)=",
    re.I)
rows = []
for t in terms:
    term = (t.get("term") or "").strip()
    href = (t.get("href") or "").strip()
    if not term or not href:
        continue
    mods = t.get("sources") or ["当日采集"]
    if isinstance(mods, str):
        mods = [mods]
    if _SEARCH_PAGE.search(href):              # 搜索结果页一律不接（无豁免）
        continue
    if _STORE_PRODUCT.search(href):            # 商店商品页不要，官方 news 公告页保留
        continue
    cat = t.get("cat") or "梗/社区"
    color = CAT_COLOR.get(cat, "#3fd68f")
    try:
        heat = int(t.get("heat", 50))
    except Exception:
        heat = 50
    rows.append({"word": term, "href": href, "color": color, "cat": cat,
                 "heat": heat, "mods": mods})

if not rows:
    sys.stderr.write("ERROR: wordcloud_terms.json 中没有有效词条。\n")
    sys.exit(1)

# ===================== 字号（按 heat）=====================
for r in rows:
    s = r["heat"]
    if s >= 70:   r["size"] = 22
    elif s >= 45: r["size"] = 19
    elif s >= 25: r["size"] = 16
    elif s >= 12: r["size"] = 14
    else:         r["size"] = 12
    r["cls"] = "h5" if r["size"] >= 19 else "h4" if r["size"] >= 15 else "h3" if r["size"] >= 13 else "h2"

# ===================== 统一热度数 H（0–100 全站唯一口径）=====================
_max = max((r["heat"] for r in rows), default=1) or 1
for r in rows:
    r["H"] = round(100 * r["heat"] / _max)
    r["reason"] = (f"热度数 H={r['H']} ｜ 来源：{'+'.join(r['mods'])}"
                   f" ｜ 原始：{int(r['heat'])}")

# ===================== 回写 HTML =====================
wc_html = '<div class="wc">' + "".join(
    f'<a class="{r["cls"]}" href="{r["href"]}" target="_blank" title="{r["reason"]}" '
    f'style="font-size:{r["size"]}px;color:{r["color"]}">{r["word"]}</a>' for r in rows) + '</div>'

legend = ('<div class="wc-legend">'
          '<span><i style="background:#ff6b4a"></i>事件/风险</span>'
          '<span><i style="background:#b388ff"></i>游戏/新品</span>'
          '<span><i style="background:#4dabf7"></i>行业/数据</span>'
          '<span><i style="background:#3fd68f"></i>梗/社区</span>'
          '<span><i style="background:#a0aec0"></i>厂商/平台</span>'
          f'<span style="opacity:.7">共 {len(rows)} 条 · AI 阅读理解当日标题提炼 · 真实来源溯源</span></div>')

def build_top8(rs):
    out = ['<h3 style="margin-top:16px">TOP8 为什么热</h3><div class="wc-list">']
    for i, r in enumerate(rs[:8], 1):
        mods = "、".join(r["mods"]) if r["mods"] else "当日采集"
        why = (f'H={r["H"]}（全站第 {i} 位）· 命中来源：{mods}'
               f' · {CAT_HINT.get(r["cat"], "当日采集信号")}')
        out.append(f'<div class="row"><span class="w" style="color:{r["color"]}">'
                   f'{r["word"]}</span><span class="why">{why}</span></div>')
    out.append('</div>')
    return "".join(out)

top8_html = build_top8(rows)

html = io.open(WC_PATH, encoding="utf-8").read()
html2 = re.sub(r'<div class="wc">.*?</div>\s*<div class="wc-legend">.*?</div>',
               wc_html + legend, html, flags=re.DOTALL)
html2 = re.sub(r'<h3[^>]*>TOP8 为什么热</h3>\s*<div class="wc-list">.*?</div>\s*</div>',
               top8_html, html2, flags=re.DOTALL)
html2 = re.sub(r'讨论热词 <small>.*?</small>',
               f'讨论热词 <small>{cloud_date} · {len(rows)} 词 · 热度数 H(0-100) 统一口径 · AI 阅读理解当日标题提炼</small>',
               html2)
html2 = re.sub(r'<span class="chip fresh">\d{4}-\d{2}-\d{2}</span>',
               f'<span class="chip fresh">{cloud_date}</span>', html2)
html2 = re.sub(r'<p class="note">热词来源：.*?</p>',
               '<p class="note">热词来源：由 AI 直接阅读当日真实采集的标题'
               '（B站热门 / 每周必看 / 梗百科账号 / 行业媒体稿 / 贴吧玩家讨论），'
               '理解语义后提炼出游戏行业热词，每条都溯源到它实际出现过的真实来源链接'
               '（B站视频 / 媒体文章 / 官方公告 / 社区话题）。'
               '<b>绝不生成 search.bilibili.com 搜索链接、绝不跳 Steam 等商店购买页</b>；'
               '无真实来源链接的词不会进入词云。'
               '<b>热度数 H（0–100 全站统一口径）</b>：每条热词展示 H，原始评分仅作附注，'
               '禁止用来源字面热度值充当热度本身（自洽红线①）。</p>',
               html2, flags=re.DOTALL)

# 写临时文件再替换，防止预览窗格锁住目标文件导致 PermissionError
_tmp = WC_PATH + "." + datetime.datetime.now().strftime("%H%M%S")
io.open(_tmp, "w", encoding="utf-8").write(html2)
try:
    os.remove(WC_PATH)
except OSError:
    pass
os.rename(_tmp, WC_PATH)
print(f"热词数: {len(rows)}")
print("分类:", dict(Counter(r["cat"] for r in rows)))
print("Top10:")
for r in rows[:10]:
    print(f"  H={r['H']:>3} [{r['cat']}] {r['word']}")
